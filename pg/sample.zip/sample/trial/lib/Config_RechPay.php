<?php
error_reporting(0);
$token = '1aa71d-a68d8b-6eb89d-b6f45c-4cd7e8'; // Your Token, (Url:http://example.com/Settings).
$secret = 'CkW9sBRYkQ'; // Your Secret Key, (Url:http://example.com/Settings).
$RECHPAY_ENVIRONMENT = 'PROD'; // PROD, TEST
?>